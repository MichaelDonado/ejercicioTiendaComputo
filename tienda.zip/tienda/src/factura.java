/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author salacomputocentro.ba
 */
public class factura {
    private String producto;
    private int cant;
    private int codigo;
    private double total;

    public factura(String producto, int cant, int cod, double total) {
        this.producto = producto;
        this.cant = cant;
        this.total = total;
        this.codigo=cod;
    }

    

    public String getProducto() {
        return producto;
    }

    public int getCant() {
        return cant;
    }

    

    public double getTotal() {
        return total;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public void setCant(int cant) {
        this.cant = cant;
    }

    @Override
    public String toString() {
        return "\nfactura N°" + codigo + 
                "\nproducto:" + producto + 
                "\n cant:" + cant +                
                "\n total:" + total ;
    }

  

    public void setTotal(double total) {
        this.total = total;
    }
    
    
    
}
